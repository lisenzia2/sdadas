AgeraDev — готовый одностраничный сайт (multi-page) для загрузки.
Файлы:
- index.html
- about.html
- portfolio.html
- contact.html
- style.css

Инструкция по публикации:
1) Откройте Google Sites (sites.google.com) — создайте новый сайт.
2) Используйте опцию 'Вставить' → 'Код HTML' или загрузите файлы на хостинг (GitHub Pages, Netlify).
3) Для GitHub Pages: создайте репозиторий, загрузите файлы и включите Pages в настройках.
